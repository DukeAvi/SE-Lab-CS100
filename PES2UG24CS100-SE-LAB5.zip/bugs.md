# Bugs Reference for Viva (`online_exam.py` — original version)

Use this file to explain *bugs* (wrong / unsafe runtime behaviour), separately
from pure style findings (which live in `issues.md`). Line numbers refer to the
**original** file. All of these are fixed in the cleaned version (Pylint
10.00/10, Bandit 0 High, Flake8 clean — all verified with `.venv/bin/python`).

## Bug 1 — Mutable default argument shares state (line 23, 30)
- **What:** `def gradeStudent(studentName, responses, penalties={}):`
- **Why it is a bug:** In Python the `{}` is created **once** at `def` time.
  Every call that omits `penalties` shares the *same* dict, so penalty counts
  accumulate across students/calls instead of starting fresh. Flagged by Pylint
  as `W0102 dangerous-default-value`.
- **Demo:** call `gradeStudent("A", {...})` then `gradeStudent("B", {...})`
  without passing `penalties` — the second call sees the first call's entries.
- **Fix:** `penalties=None` + `if penalties is None: penalties = {}`.
- **Viva one-liner:** "Never use a mutable object as a default; use `None` and
  create it inside."

## Bug 2 — Shell injection in `lockScreen` (lines 54–56)
- **What:** `os.system("ssh " + labPc + " lock-screen")`
- **Why it is a bug:** The argument is concatenated into a shell string. If
  `labPc` is attacker-controlled (e.g. `x; rm -rf ~ #`), the shell executes it.
  Bandit **B605, High/High** (CWE-78). The helper is not called by the demo,
  but any future caller inherits the hole.
- **Fix:** `subprocess.run(["/usr/bin/ssh", lab_pc, "lock-screen"],
  check=False)` — list form, `shell=False`, full path. B605 gone.
- **Viva one-liner:** "String-concatenated shell commands are injectable; always
  pass argv as a list with no shell."

## Bug 3 — Weak hash (MD5) misused for answer comparison (lines 15–16)
- **What:** `hashlib.md5(text.strip().lower().encode()).hexdigest()`
- **Why it is a bug:** MD5 is cryptographically broken (collisions); Bandit
  **B324, High/High** (CWE-327). Worse, hashing buys nothing here — answers are
  compared locally, so a plain normalised string comparison would do. It also
  hides the logic and invites "hash = security" confusion.
- **Fix:** `hashlib.sha256(...)` (minimal change; Bandit-clean). Alternative
  accepted answer: compare `given.strip().lower() == answer.strip().lower()`
  directly and delete the hash function.
- **Viva one-liner:** "MD5 must not be used; here hashing itself was unnecessary
  — SHA-256 (or plain comparison) removes the finding."

## Bug 4 — `topper()` crashes when no one is graded (lines 51–52)
- **What:** `return max(results, key=results.get)` with no empty-check.
- **Why it is a bug:** `max()` on an empty dict raises `ValueError`. Note
  `classAverage()` *does* guard (`if not results: return 0`) but `topper()`
  does not — inconsistent. No tool flags this; found by review.
- **Demo:** fresh import, call `topper()` before any `gradeStudent()` → crash.
- **Fix:** `if not results: return None`.
- **Viva one-liner:** "Every aggregation over shared state needs an empty-case;
  `classAverage` had one, `topper` did not."

## Bug 5 — `main()` runs on import (line 73)
- **What:** bare `main()` at module bottom, no
  `if __name__ == "__main__":` guard.
- **Why it is a bug:** `import online_exam` executes the whole demo, prints,
  and mutates the global `results` — surprising side effects, untestable as a
  library, double-execution under some runners.
- **Fix:** guard with `if __name__ == "__main__": main()`.
- **Viva one-liner:** "Library code must not have import-time side effects."

## Bug 6 — Hard-coded secret + dead code (line 11)
- **What:** `PROCTOR_PASSWORD = "proctor-demo"` — never read anywhere.
- **Why it is a bug:** Secret in source leaks via git (CWE-259; Bandit B105),
  and dead config rots. Low severity only because it is a demo password.
- **Fix:** `os.getenv("PROCTOR_PASSWORD", "")`; no literal secret in code.
- **Viva one-liner:** "Secrets come from the environment, never from source."

## Bug 7 — Insecure / non-reproducible randomness (lines 3, 19–20)
- **What:** `random.choice(QUESTIONS)` for the bonus question.
- **Why it is a bug:** `random` is Mersenne Twister — deterministic if seeded,
  not cryptographic (Bandit B311, CWE-330). For an exam picker, fairness /
  unpredictability matters.
- **Fix:** `secrets.choice(QUESTIONS)`.
- **Viva one-liner:** "`random` is for simulations; `secrets` is for anything
  fairness- or security-relevant."

## Non-bugs you may be asked about (style, not behaviour)
- camelCase names (`hashAnswer`, `studentName`, …) — PEP 8 violation (Pylint
  C0103), fixed by snake_case rename; behaviour unchanged.
- Missing docstrings, `range(len(...))` vs `enumerate`, `elif`-after-`return`,
  E302/E225/E261/E501 — readability/CI issues, all fixed; demo output
  verified identical (Anil 2/C, Divya 4/A, Sameer 0/C, avg 2.0, Topper Divya;
  only the bonus-question line varies, as designed).

## Likely viva questions + short answers
- *Q: How did you prove fixes preserved behaviour?* A: Captured baseline output
  with `.venv/bin/python online_exam.py` before edits; re-ran after fixes —
  scores/grades/average/topper identical; re-ran all three tools via the venv
  (Pylint 5.65→10.00, Flake8 4→0, Bandit 2 High→0 High).
- *Q: Why did you use a venv?* A: To avoid polluting the system Python
  (no `--break-system-packages`); `.venv/` is git-ignored, tools are installed
  with `.venv/bin/pip install pylint bandit flake8`, and every command runs as
  `.venv/bin/python -m ...`.
- *Q: Why is the residual Bandit Low (B404 `import subprocess`) acceptable?*
  A: It is informational — merely importing `subprocess` triggers it. The
  dangerous pattern (shell=True / string command) is gone; the call uses list
  form + full path.
- *Q: Which finding had the highest real-world risk?* A: B605 command injection
  — it allows arbitrary shell execution; fixed by removing the shell entirely.
