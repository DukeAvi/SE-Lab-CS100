# Lab 5 — Reflection

All work was done inside a project venv (`.venv`, git-ignored) so the system Python stayed clean:

```
python3 -m venv .venv
.venv/bin/pip install pylint bandit flake8
.venv/bin/python online_exam.py
.venv/bin/python -m pylint online_exam.py > pylint_report.txt
.venv/bin/python -m bandit -r online_exam.py > bandit_report.txt
.venv/bin/python -m flake8 online_exam.py > flake8_report.txt
```

Tool versions in venv: Pylint 4.1.3, Bandit 1.9.4, Flake8 7.4.1 on Python 3.13.5.
Baseline was Pylint **5.65/10**, Flake8 **4 warnings**, Bandit **2 High, 0 Medium, 2 Low**.
Final is Pylint **10.00/10**, Flake8 **clean (empty report)**, Bandit **0 High, 0 Medium, 1 Low**.
Line numbers below refer to the original `online_exam.py`. Full table is in `issues.md`.

## 1. Which issues were the easiest to fix, and which were the hardest? Why?

The easiest fixes were the ones where the tool tells you almost exactly what to do and there is no behaviour decision to make. Flake8 was like that. It reported exactly 4 warnings: `E302 expected 2 blank lines, found 1` before `lockScreen`, `E225 missing whitespace around operator` for `average=...`, `E261 at least two spaces before inline comment`, and `E501 line too long (93 > 79)` on the final print. I just added a blank line, put spaces around `=`, added one more space before the `#`, and wrapped the long `print()` over multiple lines. I re-ran `.venv/bin/python -m flake8 online_exam.py` and it went to zero output. Nothing about the program logic changed, so there was nothing to think about.

The next easiest group was the mechanical Pylint style fixes. Missing docstrings (`C0114` for the module + `C0116` for all 8 functions) just meant writing one docstring per function plus a module docstring. The nine `C0103 invalid-name` hits (`hashAnswer`, `pickBonusQuestion`, `gradeStudent`, `getGrade`, `classAverage`, `lockScreen`, `studentName`, `labPc`) just meant renaming everything to `snake_case`: `hash_answer`, `pick_bonus_question`, `grade_student`, `get_grade`, `class_average`, `lock_screen`, `student_name`, `lab_pc`. Similarly `C0200 consider-using-enumerate` told me to change:

```python
for i in range(len(QUESTIONS)):
    ... QUESTIONS[i] ...
```

to:

```python
for index, question in enumerate(QUESTIONS):
```

and `R1705 no-else-return` told me to change `elif percent >= 60` after `return "A"` into a plain second `if` plus a bare `return "C"`. These took a bit of typing but Pylint re-check confirmed each one was gone, and I verified the demo still printed Anil 2/C, Divya 4/A, Sameer 0/C.

The medium-difficulty ones were small but I had to actually understand Python to get them right. The mutable default `def gradeStudent(studentName, responses, penalties={})` flagged as `W0102 dangerous-default-value` is the classic trap: that `{}` is created once at `def` time and then shared by every call that omits `penalties`, so penalty counts leak from one student to the next. The fix is always the same pattern:

```python
def grade_student(student_name, responses, penalties=None):
    if penalties is None:
        penalties = {}
```

The Bandit Lows were the same level: `B105` hard-coded `PROCTOR_PASSWORD = "proctor-demo"` (also dead code, never used) became `os.getenv("PROCTOR_PASSWORD", "")` so no secret lives in git, and `B311` `random.choice` for the bonus question became `secrets.choice` because `random` is Mersenne Twister and not suitable where fairness/unpredictability matters (CWE-330).

The hardest by far were the two Bandit Highs, because they forced a security judgement, not just formatting.

First, `B605 High` shell injection: `os.system("ssh " + labPc + " lock-screen")` (CWE-78). If `labPc` ever comes from outside, something like `x; rm -rf ~` would execute in a shell. I had to replace the whole approach with:

```python
subprocess.run(["/usr/bin/ssh", lab_pc, "lock-screen"], check=False)
```

so there is no shell at all (`shell=False`), arguments are passed as a list, and the full `/usr/bin/ssh` path avoids the `B607 partial-path` warning. I had to learn why the residual Lows are okay (see Q2).

Second, `B324 High` MD5: `hashlib.md5(text.strip().lower().encode())`. MD5 is broken (CWE-327), but the harder realisation was that hashing buys nothing here at all — we are just comparing local exam answers, so a plain normalised string compare would do. I kept the minimal change to `hashlib.sha256(...)` to go Bandit-clean, and noted the alternative in `issues.md`.

The other hard one no tool flagged: `topper()` did `return max(results, key=results.get)` with no empty check, while `classAverage()` did guard with `if not results: return 0`. On a fresh import `topper()` crashes with `ValueError`. Plus bare `main()` at the bottom ran the whole demo on `import`. Fixing that needed manual review and an import test: `topper()` now returns `None` on empty, and `main()` is under `if __name__ == "__main__":`.

So in short: easiest = Flake8 + renames/docstrings/enumerate where the tool is the teacher; hardest = B605/B324 + empty-state handling where I had to decide what is actually safe and correct.

## 2. Did the static analysis tools report any false positives? If so, describe one example.

Yes. The clearest one is still in my final `bandit_report.txt`:

```
Issue: [B404:blacklist] Consider possible security implications associated with the subprocess module.
Severity: Low   Confidence: High
Location: ./online_exam.py:11:0
11  import subprocess
```

That fires on the mere `import subprocess` line. I have to import `subprocess` to do the *safe* thing — the list-form `subprocess.run([...], check=False)` with no shell that fixed B605. Bandit itself says in the final metrics `Total lines skipped (#nosec): 0`, `Low: 1, Medium: 0, High: 0`, so this is the only remaining finding and it is purely informational. It does not mean my call is dangerous; it just means "you are using subprocess, stay careful". I left it and justified it instead of trying to hack around it, because removing the import would mean going back to `os.system`, which is worse.

There were two smaller noisy examples in the same area. My comment:

```python
subprocess.run(  # nosec B603 -- list form, shell=False, fixed argv
```

makes Bandit print:

```
[manager] WARNING Test in comment: list is not a test name or id, ignoring
[manager] WARNING Test in comment: form is not a test name or id, ignoring
...
```

It splits my English comment into words and thinks each word is a test ID. That is harmless parser noise. Similarly Pylint docstring/naming rules (`C0114/C0116/C0103`) can feel like false positives on a tiny 70-line demo script — pedantic — but they were technically correct, so I fixed them.

What I learned is to read `Severity + Confidence` and not chase zero blindly. A Low-confidence or informational Low like B404 is something you document and accept; a High/High like B605/B324 is something you must fix. A 10.00/10 Pylint score also does not prove correctness — it just proves pattern compliance.

## 3. How would you integrate static analysis tools into your actual software development workflow?

I would not run them once at the end like in this lab; I would run all three from day one so issues never pile up. This lab taught me they are complementary, so I would keep all three: Bandit for security, Pylint for logic/maintainability, Flake8 (or Black/Ruff) for formatting. Running only one would have missed whole classes — Bandit was the only one to find the two Highs, Pylint was the only one to find the mutable-default bug, Flake8 was the only one to enforce the blank-line/spacing gates.

Concretely, what I will do on my next project:

1. **Start with a venv, never system Python.** `python3 -m venv .venv` and `.venv/bin/pip install pylint bandit flake8`, keep `.venv/` git-ignored. I did not want to use `--break-system-packages`, and this kept everything reproducible. Every command runs as `.venv/bin/python -m ...`.
2. **Fast feedback in the editor.** Enable Pylint + Flake8 on save so `E302/E225/E501`, missing docstrings, and bad names show while I type instead of in a big report later.
3. **Pre-commit hooks + CI gate.** Add a hook that runs `flake8` and `black --check` plus `bandit -r` and `pylint` on changed files. In CI, fail the build on any Bandit High/Medium or Flake8 error, and enforce the lab's rule of Pylint above 9.5 (I hit 10.00/10 here). Lows like B404 get triaged in the PR, not auto-failed.
4. **Baseline-before-refactor habit.** Before any cleanup, run and save the program output (`Anil/Divya/Sameer scores, average 2.0, topper Divya` here, bonus line excluded because it is random by design) and re-run after. In a real app that means keeping a small test suite — static analysis finds patterns, not intent; only tests + output comparison prove I did not break behaviour.
5. **Secure defaults as rules.** After seeing these bugs, my personal checklist is now: never `penalties={}`, never `os.system` with string concatenation, never hard-code a secret, never MD5, use `secrets` for anything fairness/security relevant, guard every aggregation for empty input, and guard `main()` with `if __name__ == "__main__":`. I would put several of those in a team style guide and let the linters enforce them.

In short: venv + editor feedback for speed, pre-commit + CI for enforcement, and human review + tests for what tools cannot see (like the `topper()` empty crash).

## 4. What tangible improvements did you observe in the code quality, readability, or potential robustness after applying the fixes?

The numbers moved first and they were not just cosmetic. Pylint went `5.65/10 → 10.00/10` (`pylint_report.txt` now says `Your code has been rated at 10.00/10`), Flake8 went `4 warnings → clean` (`flake8_report.txt` is empty), Bandit went `2 High, 0 Medium, 2 Low → 0 High, 0 Medium, 1 Low` (only the informational B404 import notice left). I documented 11 rows in `issues.md` (Highs first as required) and fixed well over the required 4, then re-ran all three tools via the venv to confirm each finding was gone.

Readability improved in a way I can feel when re-reading the file. Before, I had `hashAnswer`, `pickBonusQuestion`, `gradeStudent(studentName, ...)`, `classAverage`, `lockScreen(labPc)` — now everything is `snake_case` (`hash_answer`, `pick_bonus_question`, `grade_student`, `class_average`, `lock_screen`) with a module docstring and one docstring per function, so Pylint `C0103/C0114/C0116` are gone. The loop is now `for index, question in enumerate(QUESTIONS):` instead of `for i in range(len(QUESTIONS))`, `get_grade` is flat `if/if/return` instead of `if/elif/else-after-return`, and the final long `print` is wrapped. Flake8 passing means the file would now pass a CI style gate, which it would have failed before.

Robustness and security are the real win. The program still does its job — I ran `.venv/bin/python online_exam.py` before and after and the deterministic part is identical: Anil scored 2 grade C, Divya scored 4 grade A, Sameer scored 0 grade C, class average 2.0, topper Divya, student list sorted with total 3; only the first `Bonus question:` line varies because `secrets.choice` is random by design. But underneath: there is no more RCE vector (no shell, argv list, full `/usr/bin/ssh` path), no more broken MD5 (SHA-256, with a note that plain comparison would also do), no secret in source (`os.getenv`), no unpredictable `random` for the picker, no shared `penalties={}` state leaking between students, no `ValueError` when `topper()` is called before anyone is graded (returns `None`), and importing the module no longer runs the demo and pollutes `results`. Those last two I verified by import-testing, because no tool covers them.

So the code went from "works, but only just" as the README says, to clean scores plus genuinely safer and more predictable behaviour, with proof that the visible behaviour did not change.
