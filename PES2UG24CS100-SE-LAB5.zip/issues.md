# Lab 5 — Static Analysis Issues (`online_exam.py`, original version)

All work was done inside a project venv (`.venv`, git-ignored); the system
Python has none of these tools installed.

Setup used:

```
python3 -m venv .venv
.venv/bin/pip install pylint bandit flake8
.venv/bin/python online_exam.py
.venv/bin/python -m pylint online_exam.py > pylint_report.txt
.venv/bin/python -m bandit -r online_exam.py > bandit_report.txt
.venv/bin/python -m flake8 online_exam.py > flake8_report.txt
```

Tool versions (in venv): Pylint 4.1.3, Bandit 1.9.4, Flake8 7.4.1 (Python 3.13.5).
Original Pylint score: **5.65/10**. Final Pylint score: **10.00/10**.
Original Bandit: **2 High, 0 Medium, 2 Low**. Final Bandit: **0 High, 0 Medium, 1 Low** (B404 import-subprocess notice only).
Original Flake8: **4 warnings**. Final Flake8: **clean** (empty report).

High-severity (security) issues are listed first, as required.

| Issue | Type | Line(s) | Description | Fix Approach |
|-------|------|---------|-------------|--------------|
| Weak hash MD5 for answer comparison (B324, High) | Security (Bandit) | 16 | `hashlib.md5(...)` is cryptographically broken (CWE-327). Here it is only used to compare exam answers, so hashing adds no security and uses a weak algorithm. Bandit reports `Severity: High, Confidence: High`. | Replaced with `hashlib.sha256(...)`. (Equally valid: drop hashing entirely and compare normalised strings directly.) Re-ran Bandit via venv: B324 gone. |
| OS command injection via `os.system` with shell (B605, High) | Security (Bandit) | 54–56 | `os.system("ssh " + labPc + " lock-screen")` concatenates an argument into a shell command (CWE-78). A malicious `labPc` such as `x; rm -rf ~` would execute. Bandit reports `Severity: High, Confidence: High`. | Replaced with `subprocess.run(["/usr/bin/ssh", lab_pc, "lock-screen"], check=False)` — argument list, `shell=False`, full executable path. Re-ran Bandit: B605 gone (only residual Low B404 import notice remains, which is informational). |
| Mutable default argument `penalties={}` (W0102) | Correctness / Pylint warning | 23, 30 | Default `{}` is created once at function-definition time and shared across all calls. Penalty counts leak between students/calls when the caller omits the argument. Pylint: `W0102: Dangerous default value {} as argument`. | Changed signature to `penalties=None` and added `if penalties is None: penalties = {}` inside the function. Re-ran Pylint: W0102 gone. Behaviour of demo (`results`) unchanged. |
| `topper()` crashes on empty data + `main()` runs on import | Correctness / robustness (manual review) | 51–52, 73 | `max(results, key=results.get)` raises `ValueError` if `results` is empty (unlike `classAverage()`, which guards with `if not results`). Additionally, bare `main()` at line 73 executes the demo on every `import`, polluting state for library use. No tool flags the crash directly. | `topper()` now returns `None` when `results` is empty; `main()` is guarded by `if __name__ == "__main__":`. Verified by importing the module and calling `topper()` on empty state. |
| Hard-coded proctor password (B105, Low) | Security (Bandit) | 11 | `PROCTOR_PASSWORD = "proctor-demo"` embeds a secret in source (CWE-259). It is also dead code (never used). Bandit: `Severity: Low`. | Read from environment instead: `os.getenv("PROCTOR_PASSWORD", "")`. No literal secret remains; Bandit B105 gone. |
| Predictable RNG for bonus question (B311, Low) | Security / quality (Bandit) | 3, 19–20 | `random.choice` uses Mersenne Twister, unsuitable for security contexts (CWE-330). For an exam picker this is fairness-relevant. Bandit: `Severity: Low`. | Switched to `secrets.choice` (`import secrets`). Re-ran Bandit: B311 gone. Demo output still varies only on the bonus line, as before. |
| Non-PEP 8 naming — camelCase functions/args (C0103, ×9) | Style (Pylint) | 15, 19, 23 (`studentName`), 35, 45, 51, 54 (`labPc`) | `hashAnswer`, `pickBonusQuestion`, `gradeStudent`, `getGrade`, `classAverage`, `lockScreen`, `studentName`, `labPc` violate `snake_case` (PEP 8). Pylint `C0103: invalid-name` (9 hits). | Renamed to `hash_answer`, `pick_bonus_question`, `grade_student`, `get_grade`, `class_average`, `lock_screen`, `student_name`, `lab_pc`. Re-ran Pylint: all C0103 gone. |
| Missing docstrings (C0114, C0116, ×9) | Maintainability (Pylint) | 1, 15, 19, 23, 35, 45, 51, 54, 59 | No module docstring and no function docstrings. Pylint reports 1× C0114 + 8× C0116. | Added a module docstring and one docstring per function. Re-ran Pylint: all C0114/C0116 gone. |
| `range(len(...))` instead of `enumerate` (C0200) | Readability (Pylint) | 25 | `for i in range(len(QUESTIONS))` then `QUESTIONS[i]` is unidiomatic and error-prone. Pylint: `C0200: Consider using enumerate`. | Rewrote as `for index, question in enumerate(QUESTIONS):`. Re-ran Pylint: C0200 gone. |
| Unnecessary `elif` after `return` (R1705) | Readability (Pylint) | 37–41 | `elif percent >= 60` after `return "A"` nests needlessly. Pylint: `R1705: no-else-return`. | Changed second branch to plain `if` and final `else` to bare `return "C"`. Re-ran Pylint: R1705 gone. Behaviour verified identical (Anil 2→C, Divya 4→A, Sameer 0→C). |
| Flake8 style violations (E302, E225, E261, E501) | Style (Flake8) | 54, 67, 69, 70 | `E302: expected 2 blank lines, found 1` (before `lockScreen`); `E225: missing whitespace around operator` (`average=...`); `E261: at least two spaces before inline comment`; `E501: line too long (93 > 79)` (final print). | Added blank line, spaces around `=`, two spaces before `#`, wrapped the long `print` call. Re-ran Flake8 via venv: clean (0 warnings). |

## Verification

- Baseline (original) demo output noted via `.venv/bin/python online_exam.py`: `Anil 2 C / Divya 4 A / Sameer 0 C / avg 2.0 / Topper Divya` (bonus line varies randomly).
- After fixes, demo output is identical apart from the (expected) random bonus line.
- Final tool runs (all via `.venv/bin/python -m ...`): Pylint `10.00/10`; Flake8 no output; Bandit 0 High / 0 Medium / 1 Low (B404 `import subprocess` notice only).
- Reports saved as `pylint_report.txt`, `bandit_report.txt`, `flake8_report.txt` (final clean runs).
